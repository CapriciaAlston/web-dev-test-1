=== Spider Facebook===
Contributors: webdorado
Donate link: http://web-dorado.com/products/wordpress-facebook.html
Tags: player, facebook, omments, Facebook registration, facebook platform, friends, Like, like button, open graph, page, plugin, posts, sidebar, social, Social Plugins
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Spider Facebook is a WordPress integration tool for Facebook.It includes all the available Facebook social plugins and widgets to be added to your website. 
== Description ==

###[Spider Facebook](http://web-dorado.com/products/wordpress-facebook.html)


Features of Spider [Facebook](http://web-dorado.com/products/wordpress-facebook.html):  

* LinkedIn, Twitter, Google, and Facebook social widgets(commercial version)		
* Facebook Like Button	
* Facebook Send Button	
* Facebook Follow plugin that allows Facebook users to subscribe to other Facebook members from your website.	
* Facebook Comments box	
* Facebook Activity Feed	
* Facebook Recommendations Box	
* Facebook Like Box that allows liking your Facebook Page, as well as viewing its stream from your website.	
* Facebook Login Button which also contains the Facebook profile pictures of the user's Facebook friends who have signed up for your website.	
* Facebook Facepile that shows the Facebook profile pictures of the Facebook users who have liked your Facebook page or have signed up for your site.	
* Facebook Request Dialog for sending a Facebook Request from one Facebook user to one or more Facebook users.	
* Facebook Register 	

 
### Supported languages

 *If you need language which is not included in this list, please contact us and we will do the translation within 3 days. If you find some mistakes in the translation, please contact us and we will correct it within 3 days.*

Afrikaans (af)  
Albanian (sq)  
Arabic (ar)  
Armenian (hy_AM)  
Belarusian (be_BY)  
Bulgarian (bg_BG)  
Catalan (ca)  
Chinese, Simplified (zh_CN)  
Croatian (hr)  
Czech (cs_CZ)  
Danish (da_DK)  
Dutch (nl_NL)  
Esperanto (eo_EO)  
Estonian (et)  
Finnish (fi)  
French (fr_FR)  
Galician (gl_ES)  
Georgian (ka_GE)  
German (de_DE)  
Greek (el)  
Hebrew (he_IL)  
Hindi (hi_IN)  
Hungarian (hu_HU)  
Indonesian (id_ID)  
Italian (it_IT)  
Japanese (ja)  
Korean (ko_KR)  
Latvian (lv)  
Lithuanian (lt_LT)  
Macedonian (mk_MK)  
Malay (ms_MY)  
Maltese (mt_MT)  
Norwegian (nb_NO)  
Persian (fa_IR)  
Polish (pl_PL)  
Portuguese (pt_PT)  
Russian (ru_RU)  
Romanian (ro_RO)  
Serbian (sr_RS)  
Slovak (sk_SK)  
Spanish (es_ES)  
Swedish (sv_SE)  
Tamil (ta)  
Thai (th)  
Turkish (tr_TR)  
Ukrainian (uk_UA)  
Vietnamese (vi)  

== Installation ==

####Thank you for your interest in Spider [Facebook](http://web-dorado.com/products/wordpress-facebook.html).

Minimum requirements:  

* Wordpress 3.0+  
* PHP 5.x  
* MySQL 5.x  

After downloading the ZIP file  
1.  Login to your WordPress site administrator panel and head over the 'Plugins' menu  
2.  Click 'Add New'  
3.  Choose the 'Upload' option
4.  Click **Choose file** (**Browse**) and select the Spider Facebook zip file.  
5.  Click **Install Now** button.  
6.  Once it is complete, activate the plugin.  

Once the plugin is activated, you'll notice a menu on the left called "Facebook".  
If any problem occurs with [Spider Facebook](http://web-dorado.com/products/wordpress-facebook.html), please contact us info@web-dorado.com.  

== Screenshots ==
1.  Spider Facebook - Social networks	 
2.  Spider Facebook - All social buttons	
3.  Spider Facebook - Add a Facebook 	
4.  Spider Facebook  - Likebox	
5.  Spider Facebook - Social networks	 
6.  Spider Facebook - Comments 	
7.  Spider Facebook -  Share button		


== Spider Facebook Step by step guide Step 1 ==    
= Installing Spider Facebook =    
  
1.1 Minimum requirements.	
*	Wordpress 3.0+		
*	PHP 5.x		
*	MySQL 5.x		

1.2 Perform a new installation.		
1.	Log in to the administrator panel.		
2.	Go to Plugins Add New > Upload.		
3.	Click "Choose file" and select the Spider Facebook zip file.	
4.	Click the "Install Now" button.		
5.	Click the "Activate Plugin" to activate the plugin.		 
If the installation is successful, you will see a notification message. If any problem occurs, please contact us at info@web-dorado.com.		

== Spider Facebook Step by step guide Step 2 ==    
= Adding Facebook social plugins to the website =   	

*	From the navigation bar on the left select Spider Facebook>Manage Facebook.			
*	On the upper left hand of the screen click on the Add a Facebook Plugin button.			

2.1 Adding a Like Button 	
2.1.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.1.2 Publish. Choose whether to publish the plugin or not.		
2.1.3 Rendering. Choose how to render the plugin. IFRAME does not allow adding a Send Button. The URL option allows placing a link that redirects to a page with the plugin. Specify the link title in the Link text field, as well as the new page Target.		
2.1.4 Type of URL. By default, the plugin refers to the current page, but it is possible to link it to a different page by choosing the URL option and filling out the Url field.	
2.1.5 App ID. Enter your Facebook Application ID.	
2.1.6 Width. Specify the width (in pixels) of the plugin container.	
2.1.7 Button Label. Choose the button label.	
2.1.8 Show Send Button. Choose whether to place a Send button next to the Like button or not.	
2.1.9 Show Page Fans. Choose whether to show Page Fans or not.	
2.1.10 Layout style. Select a layout style for the plugin.	
2.1.11 Background color. Choose a background color for the plugin container.	
2.1.12 Color Scheme. Select the color scheme of the plugin.		
2.1.13 Font. Choose the text font of the plugin.	
2.1.14 Language Preference. 	
*	Custom. Select the plugin language.		
*	Current. Adjusts to the language of the website.		
2.1.15 All Posts. Adds the plugin to all the posts on the website.		
2.1.16 Default image for Posts. When a user likes a post, the activity, along with the post description, appears on his/her Facebook wall. This option allows providing a default image that will accompany all the posts liked by the users.		
2.1.17 Posts. Choose the posts to which you want to add the plugin. The following META tags allow you to customize the appearance of the chosen post on the user's wall. Note that certain META tags are filled out automatically, but you can edit them.		
-	Title. The title of the post. 	
-	Type. The source website will be categorized by the chosen type.	
-	URL. For providing a canonical address for the post.		
-	Image. The image accompanying the published post.		
-	Site Name. For specifying a name for your website.		
-	Description. For providing a description for the post.		
-	Admin ID. You can fill out the Admin ID of your Facebook page to connect the published post to the page.		
2.1.18 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.1.19 On all pages. Adds the plugin to all the pages on the website.		
2.1.20 Default image for pages.  Provide a default image for all the pages.		
2.1.21 Pages. Choose the pages to which you want to add the plugin. The following META tags allow you to customize the appearance of the chosen pages on the user's wall.		
2.1.22 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.1.23 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.		
2.1.24 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example:
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">		


2.2 Adding a Send Button		
2.2.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.	
2.2.2 Publish. Choose whether to publish the plugin or not.		
2.2.3 Rendering. Choose how to render the plugin.		
2.2.4 Type of URL. By default, the plugin refers to the current page, but it is possible to link it to a different page by choosing the URL option and filling out the Url field.		
2.2.5 Color Scheme. Select the color scheme of the plugin.		
2.2.6 Font. Choose the text font of the plugin.		
2.2.7 Language Preference.			
*	Custom. Select the plugin language.		
*	Current. Adjusts to the language of the website.		
2.2.8 All Articles. Adds the plugin to all the articles on the website.		
2.2.9 Default image for Posts. When a user likes a post, the activity, along with the post description, appears on his/her Facebook wall. This option allows providing a default image that will accompany all the posts shared by the users.		
2.2.10 Posts. Choose the posts to which you want to add the plugin. The following META tags allow you to customize the appearance of the chosen article on the user's wall. Note that certain META tags are filled out automatically, but you can edit them.		
-	Title. The title of the post. 		
-	Type. The source website will be categorized by the chosen type.		
-	URL. For providing a canonical address for the post.		
-	Image. The image accompanying the published post.		
-	Site Name. For specifying a name for your website.		
-	Description. For providing a description for the post.		
-	Admin ID. You can fill out the Admin ID of your Facebook page to connect the published post to the page.		
2.2.11 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.2.12 On all pages. Adds the plugin to all the pages on the website.		
2.2.13 Default image for pages.  Provide a default image for all the pages.		
2.2.14 Add pages. Choose pages to which you want to add the plugin. The following META tags allow you to customize the appearance of the chosen pages on the user's wall.		
2.2.15 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.2.16 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.		
2.2.17 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">			


2.3 Adding a Comments Box		
2.3.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.3.2 Publish. Choose whether to publish the plugin or not.		
2.3.3 Rendering. Choose how to render the plugin.		
2.3.4 Type of URL. By default, the plugin refers to the current page, but it is possible to link it to a different page by choosing the URL option and filling out the Url field.		
2.3.5 Width. Define the width of the plugin in pixels.		
2.3.6 Height. Define the height of the plugin in pixels.		
2.3.7 Number of posts. Specify how many posts are displayed by default.		
2.3.8 Background color. Select the background color of the plugin container.		
2.3.9 Color Scheme. Select the color scheme of the plugin.		
2.3.10 Font. Choose the text font of the plugin.		
2.3.11 Language Preference.		
*	Custom. Select the plugin language.		
*	Current. Adjusts to the language of the website.		
2.3.12 All Posts. Adds the plugin to all the posts on the website.		
2.3.13 Posts. Choose the posts to which you want to add the plugin.		
2.3.14 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.3.15 On all Pages. Adds the plugin to all the pages on the website.		
2.3.16 Pages. Choose the pages to which you want to add the plugin. 		
2.3.17 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.3.18 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.		
2.3.19 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">		


2.4 Adding a Like Box 		
2.4.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.4.2 Publish. Choose whether to publish the plugin or not.		
2.4.3 Rendering. Choose how to render the plugin. The URL option allows placing a link that redirects to a page with the plugin. Specify the link title in the Link text field, as well as the new page Target.		
2.4.4 Facebook Page Url. Enter the URL of your Facebook page.		
2.4.5 Width. Define the width of the plugin in pixels.		
2.4.6 Height. Define the height of the plugin in pixels.		
2.4.7 Show Header. Choose whether to show the Facebook header at the top of the plugin container or not.		
2.4.8 Show Stream. Choose whether to show the profile stream for the public profile or not.		
2.4.9 Show Page Fans. Choose whether to show Page Fans or not.		
2.4.10 Border. Choose whether to display the border of the plugin container or not.		
2.4.11 Border Color. Select the border color of the plugin container.		
2.4.12 Background Color. Select the background color of the plugin container.		
2.4.13 Color Scheme. Select the color scheme of the plugin.		
2.4.14 Font. Choose the text font of the plugin.		
2.4.15 Language Preference. 		
*	Custom. Select the plugin language.		
*	Current. Adjusts to the language of the website.		
2.4.16 All Posts. Adds the plugin to all the posts on the website.		
2.4.17 Posts. Choose the posts to which you want to add the plugin.		
2.4.18 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.4.19 On all Pages. Adds the plugin to all the pages on the website.		
2.4.20 Pages. Choose the pages to which you want to add the plugin. 		
2.4.21 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.4.23 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).
Example:
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">		


2.5 Adding a Follow Button		
2.5.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.5.2 Publish. Choose whether to publish the plugin or not.		
2.5.3 Rendering. Choose how to render the plugin. The URL option allows placing a link that redirects to a page with the plugin. Specify the link title in the Link text field, as well as the new page Target.		
2.5.4 Facebook Profile Url. Enter the URL of your Facebook profile.		
2.5.5 Width. Define the width of the plugin in pixels.		
2.5.6 Show Page Fans. Choose whether to show Page Fans or not.		
2.5.7 Layout style. Select a layout style for the plugin.		
2.5.8 Border. Choose whether to display the border of the plugin container or not.		
2.5.9 Border Color. Select the border color of the plugin container.		
2.5.10 Background Color. Select the background color of the plugin container.		
2.5.11 Color Scheme. Select the color scheme of the plugin.		
2.5.12 Font. Choose the text font of the plugin.		
2.5.13 All Posts. Adds the plugin to all the posts on the website.		
2.5.14 Posts. Choose the posts to which you want to add the plugin.		
2.5.15 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.5.16 On all Pages. Adds the plugin to all the pages on the website.		
2.5.17 Pages. Choose the pages to which you want to add the plugin. 		
2.5.18 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.5.19 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.		
2.5.20 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">		


2.6 Adding a Request Dialog		
2.6.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.6.2 Publish. Choose whether to publish the plugin or not.		
2.6.3 App id. Enter your Facebook Application ID.		
2.6.4 Request Message. Here you can add a message that will accompany the request.		
2.6.5 Request type. Choose whether to enable request for one or multiple users.		
2.6.6 All Posts. Adds the plugin to all the posts on the website.	
2.6.7 Posts. Choose the posts to which you want to add the plugin.		
2.6.8 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.6.9 On all Pages. Adds the plugin to all the pages on the website.		
2.6.10 Pages. Choose the pages to which you want to add the plugin. 		
2.6.11 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.6.12 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.		
2.6.13 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">		

2.7 Adding a Recommendations Box		
2.7.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.7.2 Publish. Choose whether to publish the plugin or not.		
2.7.3 Rendering. Choose how to render the plugin.		
2.7.4 Domain. Specify the domain for which you want the information to be shown. By default, it is the domain on which the plugin is added.		
2.7.5 App id. Enter your Facebook Application ID.		
2.7.6 Width. Define the width of the plugin in pixels.		
2.7.7 Height. Define the height of the plugin in pixels.		
2.7.8 Target. Select the context in which content links are opened.		
2.7.9 Show Header. Choose whether to show the Facebook header at the top of the plugin container or not.		
2.7.10 Show Recommendations. Choose whether to show user recommendations or not.		
2.7.11 Border Color. Select the border color of the plugin container.		
2.7.12 Background Color. Select the background color of the plugin container.		
2.7.13 Color Scheme. Select the color scheme of the plugin.		
2.7.14 Font. Choose the text font of the plugin.		
2.7.15 Language Preference. 		
*	Custom. Select the plugin language.		
*	Current. Adjusts to the language of the website.		
2.7.16 All Posts. Adds the plugin to all the posts on the website.		
2.7.17 Posts. Choose the posts to which you want to add the plugin.		
2.7.18 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.7.19 On all Pages. Adds the plugin to all the pages on the website.		
2.7.20 Pages. Choose the pages to which you want to add the plugin. 		
2.7.21 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.7.22 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.		
2.7.23 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">		

2.8 Adding an Activity Feed		
2.8.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.8.2 Publish. Choose whether to publish the plugin or not.		
2.8.3 Rendering. Choose how to render the plugin.		
2.8.4 Domain. Specify the domain for which you want the information to be shown. By default, it is the domain on which the plugin is added.		
2.8.5 App id. Enter your Facebook Application ID.		
2.8.6 Width. Define the width of the plugin in pixels.		
2.8.7 Height. Define the height of the plugin in pixels.		
2.8.8 Target. Select the context in which content links are opened.		
2.8.9 Show Header. Choose whether to show the Facebook header at the top of the plugin container or not.		
2.8.10 Show Recommendations. Choose whether to show user recommendations or not.		
2.8.11 Button label. Choose the button label.		
2.8.12 Border Color. Select the border color of the plugin container.		
2.8.13 Background Color. Select the background color of the plugin container.		
2.8.14 Color Scheme. Select the color scheme of the plugin.		
2.8.15 Font. Choose the text font of the plugin.		
2.8.16 Language Preference. 		
*	Custom. Select the plugin language.		
*	Current. Adjusts to the language of the website.		

2.8.17 All Posts. Adds the plugin to all the posts on the website.		
2.8.18 Posts. Choose the posts to which you want to add the plugin.		
2.8.19 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.8.20 On all Pages. Adds the plugin to all the pages on the website.		
2.8.21 Pages. Choose the pages to which you want to add the plugin. 		
2.8.22 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.8.23 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.		
2.8.23 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">		


2.9 Adding a Facepile		
2.9.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.9.2 Publish. Choose whether to publish the plugin or not.		
2.9.3 Rendering. Choose how to render the plugin. The URL option allows placing a link that redirects to a page with the plugin. Specify the link title in the Link text field, as well as the new page Target.		
2.9.4 Facebook Page Url. Enter the URL of your Facebook page.		
2.9.5 Width. Define the width of the plugin in pixels.		
2.9.6 Max Rows. Specify the maximum number of rows of profile pictures.		
2.9.7 Image Size. Define the size of the images.		
2.9.8 Button label. Choose the button label.		
2.9.9 Border. Choose whether to display the border of the plugin container or not.		
2.9.10 Border Color. Select the border color of the plugin container.		
2.9.11 Background Color. Select the background color of the plugin container.		
2.9.12 Color Scheme. Select the color scheme of the plugin.		
2.9.13 Font. Choose the text font of the plugin.		
2.9.14 Language Preference. 	
*	Custom. Select the plugin language.		
*	Current. Adjusts to the language of the website.	
2.9.15 All Posts. Adds the plugin to all the posts on the website.		
2.9.16 Posts. Choose the posts to which you want to add the plugin.		
2.9.17 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.9.18 On all Pages. Adds the plugin to all the pages on the website.		
2.9.19 Pages. Choose the pages to which you want to add the plugin. 		
2.9.20 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.9.21 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.		
2.9.22 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">		


2.10 Adding a Share Button		
2.10.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.10.2 Publish. Choose whether to publish the plugin or not.		
2.10.3 Type of URL. By default, the plugin refers to the current page, but it is possible to link it to a different page by choosing the URL option and filling out the Url field.		
2.10.4 Share type. Choose the layout style of the plugin.		
2.10.5 All Posts. Adds the plugin to all the posts on the website.			
2.10.6 Posts. Choose the posts to which you want to add the plugin.			
2.10.7 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.10.8 On all Pages. Adds the plugin to all the pages on the website.			
2.10.9 Pages. Choose the pages to which you want to add the plugin. 	
2.10.10 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.10.11 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.			
2.10.12 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).			
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">			


2.11 Adding a Login Button		
2.11.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.11.2 Publish. Choose whether to publish the plugin or not.		
2.11.3 Rendering. Choose how to render the plugin. 		
2.11.4 App id. Enter your Facebook Application ID.		
2.11.5 Width. Define the width of the plugin in pixels.		
2.11.6 Max Rows. Specify the maximum number of rows of profile pictures.		
2.11.7 Show page fans. Choose whether to show Page Fans or not.		
2.11.8 Background Color. Select the background color of the plugin container.		
2.11.9 Color Scheme. Select the color scheme of the plugin.		
2.11.8 Font. Choose the text font of the plugin.		
2.11.9 All Posts. Adds the plugin to all the posts on the website.		
2.11.10 Posts. Choose the posts to which you want to add the plugin.		
2.11.11 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.			
2.11.12 On all Pages. Adds the plugin to all the pages on the website.		
2.11.13 Pages. Choose the pages to which you want to add the plugin. 		
2.11.14 Vertical Position. Choose whether to place the plugin at the top or at the bottom.			
2.11.15 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.			
2.11.16 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">		


2.12 Adding a Registration 		
2.12.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.			
2.12.2 Publish. Choose whether to publish the plugin or not.			
2.12.3 Domain. Specify the domain for which you want the information to be shown. By default, it is the domain on which the plugin is added.		
2.12.4 App id. Enter your Facebook Application ID.			
2.12.5 Redirect URL after registration. Specify the URL to which the user is redirected after registration.			
2.12.6 Redirect URL after login. Specify the URL to which the user is redirected after login.		
2.12.7 Allow login only via Facebook. Choose whether to allow logging in only via Facebook or not.		
2.12.8 Registration fields type. 		
*	Auto registration. Automatically generates a username and imports user profile information.		
*	Username and password. The user sets the username and password.		
*	Username, password, and captcha. Requires setting username and password and verifies with captcha.		

2.12.9 All Posts. Adds the plugin to all the posts on the website.		
2.12.10 Posts. Choose the posts to which you want to add the plugin.		
2.12.11 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.			
2.12.12 On all Pages. Adds the plugin to all the pages on the website.			
2.12.13 Pages. Choose the pages to which you want to add the plugin. 		
2.12.14 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.12.15 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.		
2.12.16 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">			

2.13 Adding a set of Linkedin, Twitter, Google, and Facebook widgets		
2.13.1 Title. Specify a title for the plugin to be able to identify the plugin in back-end.		
2.13.2 Publish. Choose whether to publish the plugin or not.		
2.13.3 Type of URL. By default, the plugin refers to the current page, but it is possible to link it to a different page by choosing the URL option and filling out the Url field.			
2.13.4 Count Box Position. Choose the position of the widget count boxes.			
2.13.5 Horizontal Position. Choose whether to place the plugin on the left or on the right hand of the page.		
2.13.6 App ID. Enter your Facebook Application ID.		
2.13.7 Language Preference. 		
*	Custom. Select the plugin language.		
*	Current. Adjusts to the language of the website.		
2.13.8 All Posts. Adds the plugin to all the posts on the website.		
2.13.9 Default image for Posts. When a user likes a post, the activity, along with the post description, appears on his/her Facebook wall. This option allows providing a default image that will accompany all the posts liked by the users.		
2.13.10 Posts. Choose the posts to which you want to add the plugin. The following META tags allow you to customize the appearance of the chosen post on the user's wall. Note that certain META tags are filled out automatically, but you can edit them.		
-	Title. The title of the post. 		
-	Type. The source website will be categorized by the chosen type.		
-	URL. For providing a canonical address for the post.		
-	Image. The image accompanying the published post.		
-	Site Name. For specifying a name for your website.		
-	Description. For providing a description for the post.		
-	Admin ID. You can fill out the Admin ID of your Facebook page to connect the published post to the page.		
2.13.11 Vertical Position. Choose whether to place the plugin at the top or at the bottom of the post.		
2.13.12 On all pages. Adds the plugin to all the pages on the website.		
2.13.13 Default image for pages.  Provide a default image for all the pages.		
2.13.14 Pages. Choose the pages to which you want to add the plugin. The following META tags allow you to customize the appearance of the chosen pages on the user's wall.		
2.13.15 Vertical Position. Choose whether to place the plugin at the top or at the bottom.		
2.13.16 Style. Here you can customize certain style options. Simply change the values of the parameters that are listed in the box.		
2.13.17 Add to <html> Tag. Add the code (ONLY ONCE) to the <html> tag of your template's index.php file (templates/your_template/index.php).		
Example: 
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">		


== Spider Facebook Step by step guide Step 3==    
= Publishing Spider Facebook in a Page or a Post =   

3.1 Open the page/post where you want to publish the Facebook plugin.		
3.2 Click on the Spider Facebook button .		
3.3 Select the Facebook plugin you want to insert and click on the Insert button. You can also edit the META tags in the Spider Facebook section at the bottom of the page. Note that these META tags have a higher priority than the ones on the Facebook plugin parameters page.		
3.4 Alternatively, you can manually insert the Facebook plugin shortcode into the post/page. Simply copy [spider_facebook id="N"] into the page/post. "N" is the ID of the plugin and can be found in the list of plugins in the Manage Facebook section of Spider Facebook.		
